

var current=1;
$(document).ready(function(){


    loadTable(current);




});

function loadTable(pnum)
{
    $("#table_content").fadeOut(300,function(){


        $.ajax({
            type: "POST",
            url: '/Payments/GetAllPayments',
            data : { pagenum: pnum  },

            success: function (data) {
                        current=pnum;
                         $('#table_content').html(data);
                         $("#table_content").fadeIn(300);
                    }
        });
     });
}
function DeleteRowTable(rowid,invoiceID)
{
    if(confirm('Are You Sure to Delete Payment?')){
        $.ajax({
            type: "POST",
            url: '/Payments/DeletePaymentRow',
            data : { row_ID: rowid , invoice_ID: invoiceID  },

            success: function (data) {
alert("Delete Row is success.");
                loadTable(current);


            }
        });
    }

}
