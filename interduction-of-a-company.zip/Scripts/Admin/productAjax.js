

var current=1;
$(document).ready(function(){


    loadTable(current);




});

function loadTable(pnum)
{
    $("#table_content").fadeOut(300,function(){


        $.ajax({
            type: "POST",
            url: '/Products/GetAllProducts',
            data : { pagenum: pnum  },

            success: function (data) {
                        current=pnum;
                         $('#table_content').html(data);
                         $("#table_content").fadeIn(300);
                    }
        });
     });
}
function DeleteRowTable(rowid)
{
    if(confirm('Are You Sure to Delete Product?')){
        $.ajax({
            type: "POST",
            url: '/Products/DeleteProductsRow',
            data : { row_ID: rowid  },

            success: function (data) {
alert("Delete Row is success.");
                loadTable(current);


            }
        });
    }

}
