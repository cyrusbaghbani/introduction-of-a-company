﻿public class HttpServerUtilityBase
{
}