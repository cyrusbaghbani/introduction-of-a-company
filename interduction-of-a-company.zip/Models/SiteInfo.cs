﻿using Models;
using PartoEng.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using App_Start.Utility;
using Utility;


namespace Models
{

    public class M_SiteInfo
    {
        protected dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();

        public string Filter;
        public string ID;
        public string Title;
        public List<SubCategory> lstubcategory = new List<SubCategory>();
        public List<Portfolio> lstporfolito = new List<Portfolio>();

        public M_SiteInfo(string Id, string Filter_ = "")
        {
            Filter = Filter_ == "" ? Id : Filter_;
            List<Service> lstservice = new List<Service>();
            Display(Id);
        }
        private void Display(string ID)
        {

            var obj = dc.SubCategories.FirstOrDefault(s => s.Id.ToString() == ID);
            Title = obj == null ? "" : obj.Category.Name;
            ID = obj == null ? "" : obj.CatagoryID.ToString();

            lstporfolito = dc.Portfolios.Where(s => s.SubCategory.CatagoryID.ToString() == ID).ToList();
            lstporfolito = lstporfolito == null ? new List<Portfolio>() : lstporfolito;

            lstubcategory = dc.SubCategories.Where(s => s.CatagoryID.ToString() == ID).ToList();
            lstubcategory = lstubcategory == null ? new List<SubCategory>() : lstubcategory;



        }
    }
}