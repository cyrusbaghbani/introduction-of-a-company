﻿using Models;
using PartoEng.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using App_Start.Utility;
using Utility;
using System.IO;

namespace Models
{

    public class M_ServiceSpec : MasterPageModel
    {
        public string TempID = "";
        public string ID = "";
        public string Title = "";
        public string Priority = "";
        public string hftempImage = "";
        public string imageurl = "";
        public string txtbgColor = "";
        public ViewPage page_;

        public M_ServiceSpec(User currentUser_, string PageName, string ID_)
        {
            Intialize(currentUser_, PageName);
            TempID = ID_ == null ? "" : ID_.Trim();
            page_ = new ViewPage("امکانات", "AServices", "ServiceSpec", true);
            Display();
        }

        public M_ServiceSpec(FormCollection frm, User currentUser_, string PageName, string ID_)
        {
            Intialize(currentUser_, PageName);
            page_ = new ViewPage("امکانات", "AServices", "ServiceSpec", true);
            TempID = ID_ == null ? "" : ID_.Trim();
            BindForms(frm);

        }
        public void BindForms(FormCollection frm)
        {
            ID = EmoNetUtility.GetQueryString("id", TempID);
            hftempImage = Utility.EncryptedQueryString.Decrypt(frm["hftempImage"].ToString().Trim());
            Title = frm["txtTitle"].ToString().Trim();
            Priority = frm["txtPrioity"].ToString().Trim();
            txtbgColor = frm["txtbgColor"].ToString().Trim();
            var obj = dc.Services.FirstOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
            {
                page_.Title = page_.Title + " / جدید";
                return;
            }
            page_.Title = page_.Title + " / ویرایش";

            var tmp = dc.Temps.FirstOrDefault(s => s.UID.ToString() == hftempImage);
            if (tmp == null)
            {
         
                if (obj != null)
                {
                    imageurl = obj.ImgUrl_340_450;
                }
            }
            else
                imageurl = tmp.Url;

        }

        public void Save(System.Web.HttpServerUtilityBase server)
        {
            bool IsInsert = false;
            var obj = dc.Services.FirstOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
            {

                obj = new Service();
                dc.Services.InsertOnSubmit(obj);
                obj.IsDeleted = false;
                IsInsert = true;
            }

            obj.Title = Title;
            obj.Priority = Priority == "" ? (int?)null : int.Parse("0" + Priority);

            var profile = dc.Profiles.FirstOrDefault();
            if (profile != null)
                profile.ServicesColor = txtbgColor;

            var tmp = dc.Temps.FirstOrDefault(s => s.UID.ToString() == hftempImage);
            if (tmp != null)
            {
                string name = obj.Id + Guid.NewGuid().ToString() + Path.GetExtension(tmp.Url);
                obj.ImgUrl_340_450 = ServicesPath + name;
                try
                {
                    File.Move(server.MapPath(tmp.Url), server.MapPath(obj.ImgUrl_340_450) );
                }
                catch { }
            }

            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsInsert)
            {
                EventLog.Loging(" درج جدید '" + page_.Title + "' با عنوان '" + Title + "'", EventTypeIds.SAVE, CurrentUser.UID);
            }
            else if (!IsInsert && Ischange)
            {
                EventLog.Loging(" ویرایش '" + page_.Title + "' با عنوان '" + Title + "'", EventTypeIds.EDIT, CurrentUser.UID);
            }


        }
        public bool CheckValidate()
        {
            var obj = dc.Services.FirstOrDefault(s => s.Id.ToString() == ID);
            bool result = true;
            string Msg = "به نکات زیر توجه نمایید" + "</br>";
            int i = 0;

            if (Title == "")
            {
                result = false;
                Msg += (++i).ToString() + " - " + " عنوان را وارد نمایید ." + "</br>";
            }
            if (obj == null && (hftempImage == null || hftempImage == ""))
            {
                result = false;
                Msg += (++i).ToString() + " - " + " عکس را انتخاب نمایید ." + "</br>";
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }
        private void Display()
        {
            ID = EmoNetUtility.GetQueryString("id", TempID);
            var obj = dc.Services.FirstOrDefault(s => s.Id.ToString() == ID);
            var profile = dc.Profiles.FirstOrDefault();
            if (profile != null)
                  txtbgColor= profile.ServicesColor;
            if (obj == null)
            {
                page_.Title = page_.Title + " / جدید";
                return;
            }
            page_.Title = page_.Title + " / ویرایش";
            imageurl = obj.ImgUrl_340_450;
            Title = obj.Title;
            Priority = obj.Priority == null ? "" : obj.Priority.Value.ToString();
        }

    }
}