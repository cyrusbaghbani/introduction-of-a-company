using System.Collections.Generic;

public class ViewPage
{
    public string Title;
    public string Action;
    public string controller_;
    public bool IsShowPriority;
    public List<TableItemList> list;
    public string hf_SelectValueID;

    public ViewPage()
    {
        Title = "";
        Action = "";
        controller_ = "";
        IsShowPriority = false;
        list = new List<TableItemList>();
    }
    public ViewPage(string Title_, string controllername_, string actionname_, bool isShowPriority_)
    {
        Title = Title_;
        Action = actionname_;
        controller_ = controllername_;
        IsShowPriority = isShowPriority_;
        list = new List<TableItemList>();
    }

}