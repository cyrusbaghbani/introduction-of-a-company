﻿using PartoEng.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Security
{
    public bool IsDisplay = true;
    public Security(User currentuser, string PageName)
    {

        SetMenu(currentuser);
        SetPageAccess(currentuser, PageName);

    }

    private void SetMenu(User currentuser)
    {
       
    }

    private void SetPageAccess(User currentuser, string pageName)
    {
        
    }
}
