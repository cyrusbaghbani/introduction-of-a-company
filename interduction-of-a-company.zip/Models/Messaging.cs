﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;


public class Messaging
{
    public string ShowMessaging = "";

    public void ShowErrorMessage(string Msg)
    {
        ShowMessaging = "ShowErrorMessage('" + Msg + "');";
    }

    public void ShowSeccessMessage(string Msg)
    {
        ShowMessaging = "ShowSeccessMessage('" + Msg + "');";
    }
    public void ShowInformationMessage(string Msg)
    {
        ShowMessaging = "ShowInformationMessage('" + Msg + "');";
    }
}
