﻿using Models;
using PartoEng.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using App_Start.Utility;
using Utility;


namespace Models
{

    public class M_ServicesList : MasterPageModel
    {

        public ViewPage page_;
 
        public M_ServicesList(User currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            page_ = new ViewPage("امکانات", "AServices", "Services", true);

        }

        public M_ServicesList(FormCollection frm, User currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            page_ = new ViewPage("امکانات", "AServices", "Services", true);
            BindForms(frm);

        }
        public void BindForms(FormCollection frm)
        {
            page_.hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
        }
        public void DeleteRow(System.Web.HttpServerUtilityBase server)
        {
            var obj = dc.Services.SingleOrDefault(s => s.Id.ToString() == page_.hf_SelectValueID);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("رکورد قبلا حذف شده است");
                return;
            }
            dc.Services.DeleteOnSubmit(obj);
            dc.SubmitChanges();
            DELETE_FILE(obj.ImgUrl_340_450, server);
            
            EventLog.Loging(" حذف رکورد با عنوان '" + obj.Title + "' از صفحه '" + page_.Title + "' انجام گردید", EventTypeIds.DELETE, CurrentUser.UID);

            DisplayMessage.ShowSeccessMessage("رکورد با موفقیت حذف گردید");
        }

        public void LoadList()
        {
            page_.list = (from p in dc.Services
                          select new TableItemList
                          {
                              ID = Utility.EncryptedQueryString.Encrypt(p.Id.ToString()),
                              Priority = p.Priority,
                              Title = p.Title,

                          }).ToList();
        }
    }
}