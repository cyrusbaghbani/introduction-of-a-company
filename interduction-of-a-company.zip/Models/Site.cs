﻿using Models;
using PartoEng.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using App_Start.Utility;
using Utility;


namespace Models
{

    public class M_SIte 
    {
        protected dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();


        public string txtKids;
        public string txtTeen;
        public string txtAdult;
        public string txtChilds;
        public string txtColorServices;
        public string txtClolorAboutUs;
        public string txtColorCards;
        public Profile profile;

        public List<string> lsturlservice = new List<string>();
        public M_SIte()
        {
            List<Service> lstservice = new List<Service>();
            Display();
        }
        private void Display()
        {
            profile = dc.Profiles.FirstOrDefault();
            profile = profile == null ? new Profile() : profile;

            lsturlservice = dc.Services.OrderBy(s=>s.Priority).Select(s=>s.ImgUrl_340_450).ToList();
            lsturlservice = lsturlservice == null ? new List<string>() : lsturlservice;

            txtKids = dc.Categories.Any(s => s.Id == CategoryType.Kodakan) ? (dc.Categories.First(s => s.Id == CategoryType.Kodakan).Dsc) : "";
            txtTeen = dc.Categories.Any(s => s.Id == CategoryType.Nojavanan) ? (dc.Categories.First(s => s.Id == CategoryType.Nojavanan).Dsc) : "";
            txtAdult = dc.Categories.Any(s => s.Id == CategoryType.Bozorgsalan) ? (dc.Categories.First(s => s.Id == CategoryType.Bozorgsalan).Dsc) : "";
            txtChilds = dc.Categories.Any(s => s.Id == CategoryType.Khordsalan) ? (dc.Categories.First(s => s.Id == CategoryType.Khordsalan).Dsc) : "";

            txtColorCards = profile.CategoryCardColor;
            txtClolorAboutUs = profile.AboutUsColor;
            txtColorServices = profile.ServicesColor;

        }
    }
}