﻿using Models;
using PartoEng.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using App_Start.Utility;
using Utility;
using System.IO;

namespace Models
{

    public class M_PortfolioSpec : MasterPageModel
    {
        public string TempID = "";
        public string ID = "";
        public string Title = "";
        public string Dsc = "";
        public string hftempImage = "";
        public string imageurl = "";
        public string hftempVideo = "";
        public string Videourl = "";
        public bool HasVideo = false;
        public ViewPage page_;

        public int subcategory;

        public M_PortfolioSpec(User currentUser_, string PageName, string ID_, bool HasVideo_, int subcategory_, string Title_, string controller_, string Action_)
        {
            Intialize(currentUser_, PageName);
            TempID = ID_ == null ? "" : ID_.Trim();
            page_ = new ViewPage(Title_, controller_, Action_, false);
            subcategory = subcategory_;
            HasVideo = HasVideo_;
            Display();
        }

        public M_PortfolioSpec(FormCollection frm, User currentUser_, string PageName, string ID_, bool HasVideo_, int subcategory_, string Title_, string controller_, string Action_)
        {
            Intialize(currentUser_, PageName);
            page_ = new ViewPage(Title_, controller_, Action_, false);
            TempID = ID_ == null ? "" : ID_.Trim();
            subcategory = subcategory_;
            HasVideo = HasVideo_;
            BindForms(frm);

        }
        public void BindForms(FormCollection frm)
        {
            ID = EmoNetUtility.GetQueryString("id", TempID);
            hftempImage = Utility.EncryptedQueryString.Decrypt(frm["hftempImage"].ToString().Trim());
            hftempVideo = frm["hftempVideo"] == null ? "" : Utility.EncryptedQueryString.Decrypt(frm["hftempVideo"].ToString().Trim());
            Title = frm["txtTitle"].ToString().Trim();
            Dsc = frm["txtDsc"].ToString().Trim();

            var obj = dc.Portfolios.FirstOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
            {
                page_.Title = page_.Title + " / جدید";
                return;
            }
            page_.Title = page_.Title + " / ویرایش";

            var tmp = dc.Temps.FirstOrDefault(s => s.UID.ToString() == hftempImage);
            if (tmp == null)
            {
                if (obj != null)
                {
                    imageurl = obj.ImageUrl;
                }
            }
            else
                imageurl = tmp.Url;

            if (HasVideo)
            {
                var tmpvedio = dc.Temps.FirstOrDefault(s => s.UID.ToString() == hftempVideo);
                if (tmpvedio == null)
                {

                    if (obj != null)
                    {
                        Videourl = obj.VideoUrl;
                    }
                }
                else
                    Videourl = tmpvedio.Url;
            }

        }

        public void Save(System.Web.HttpServerUtilityBase server)
        {
            bool IsInsert = false;
            var obj = dc.Portfolios.FirstOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
            {

                obj = new Portfolio();
                dc.Portfolios.InsertOnSubmit(obj);
                obj.DateCreate = DateTime.Now;
                obj.IsDeleted = false;
                obj.SubCategory = dc.SubCategories.First(s => s.Id == subcategory);
                IsInsert = true;
            }

            obj.Title = Title;
            obj.Dsc = Dsc;

            string OlDImgUrl = "";
            var tmp = dc.Temps.FirstOrDefault(s => s.UID.ToString() == hftempImage);
            if (tmp != null)
            {
                string name = "Image" + obj.Id + Guid.NewGuid().ToString() + Path.GetExtension(tmp.Url);
                OlDImgUrl = obj.ImageUrl;
                obj.ImageUrl = GalleryPath + name;
                try
                {
                    File.Move(server.MapPath(tmp.Url), server.MapPath(obj.ImageUrl));
                    DELETE_FILE(OlDImgUrl, server);
                }
                catch { }
            }


            if (HasVideo)
            {
                string OlDVideourl = "";
                var tmpVideo = dc.Temps.FirstOrDefault(s => s.UID.ToString() == hftempVideo);
                if (tmpVideo != null)
                {
                    string name = "Video" + obj.Id + Guid.NewGuid().ToString() + Path.GetExtension(tmpVideo.Url);
                    OlDVideourl = obj.VideoUrl;
                    obj.VideoUrl = GalleryPath + name;
                    try
                    {
                        File.Move(server.MapPath(tmpVideo.Url), server.MapPath(obj.VideoUrl));
                        DELETE_FILE(OlDVideourl, server);
                    }
                    catch { }
                }
            }
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsInsert)
            {
                EventLog.Loging(" درج جدید '" + page_.Title + "' با عنوان '" + Title + "'", EventTypeIds.SAVE, CurrentUser.UID);
            }
            else if (!IsInsert && Ischange)
            {
                EventLog.Loging(" ویرایش '" + page_.Title + "' با عنوان '" + Title + "'", EventTypeIds.EDIT, CurrentUser.UID);
            }


        }
        public bool CheckValidate()
        {
            var obj = dc.Portfolios.FirstOrDefault(s => s.Id.ToString() == ID);
            bool result = true;
            string Msg = "به نکات زیر توجه نمایید" + "</br>";
            int i = 0;

            if (Title == "")
            {
                result = false;
                Msg += (++i).ToString() + " - " + " عنوان را وارد نمایید ." + "</br>";
            }
            if (obj == null && (hftempImage == null || hftempImage == ""))
            {
                result = false;
                Msg += (++i).ToString() + " - " + " عکس را انتخاب نمایید ." + "</br>";
            }
            if (HasVideo)
            {
                if (obj == null && (hftempVideo == null || hftempVideo == ""))
                {
                    result = false;
                    Msg += (++i).ToString() + " - " + " عکس را انتخاب نمایید ." + "</br>";
                }
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }
        private void Display()
        {
            ID = EmoNetUtility.GetQueryString("id", TempID);
            var obj = dc.Portfolios.FirstOrDefault(s => s.Id.ToString() == ID);
            if (obj == null)
            {
                page_.Title = page_.Title + " / جدید";
                return;
            }
            page_.Title = page_.Title + " / ویرایش";
            imageurl = obj.ImageUrl;
            Title = obj.Title;
            Dsc = obj.Dsc == null ? "" : obj.Dsc.ToString();
            Videourl = obj.VideoUrl;
        }

    }
}