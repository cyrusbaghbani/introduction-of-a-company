﻿using Models;
using PartoEng.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using App_Start.Utility;
using Utility;

namespace Models
{
    public class M_PortfolioList : MasterPageModel
    {

        public ViewPage page_;

        private int category;
        private int subCategory;
        public M_PortfolioList(User currentUser_, string PageName, int category_, int subcategory_, string Title_, string controller_, string Action_)
        {
            Intialize(currentUser_, PageName);
            page_ = new ViewPage(Title_, controller_, Action_, false);
            category = category_;
            subCategory = subcategory_;

        }

        public M_PortfolioList(FormCollection frm, User currentUser_, string PageName, int category_, int subcategory_, string Title_, string controller_, string Action_)
        {
            Intialize(currentUser_, PageName);
            page_ = new ViewPage(Title_, controller_, Action_, false);
            category = category_;
            subCategory = subcategory_;
            BindForms(frm);

        }
        public void BindForms(FormCollection frm)
        {
            page_.hf_SelectValueID = Utility.EncryptedQueryString.Decrypt(frm["hf_SelectValueID"].ToString().Trim());
        }


        public void DeleteRow(System.Web.HttpServerUtilityBase server)
        {
            var obj = dc.Portfolios.SingleOrDefault(s => s.Id.ToString() == page_.hf_SelectValueID && s.SubCategoryID == subCategory);
            if (obj == null)
            {
                DisplayMessage.ShowErrorMessage("رکورد قبلا حذف شده است");
                return;
            }
            dc.Portfolios.DeleteOnSubmit(obj);
            dc.SubmitChanges();
            DELETE_FILE(obj.ImageUrl,server);
            DELETE_FILE(obj.VideoUrl,server);
            EventLog.Loging(" حذف رکورد با عنوان '" + obj.Title + "' از صفحه '" + page_.Title + "' انجام گردید", EventTypeIds.DELETE, CurrentUser.UID);
            DisplayMessage.ShowSeccessMessage("رکورد با موفقیت حذف گردید");
        }
        public void LoadList()
        {
            page_.list = (from p in dc.Portfolios
                          where
                          p.SubCategoryID == subCategory
                          select new TableItemList
                          {
                              ID = Utility.EncryptedQueryString.Encrypt(p.Id.ToString()),
                              Priority = 0,
                              Title = p.Title,

                          }).ToList();


        }
    }
}