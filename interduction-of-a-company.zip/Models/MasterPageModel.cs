﻿using PartoEng.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utility;

namespace Models
{
    public class MasterPageModel
    {
        protected dbPartoAlaviDataContext dc ;
        protected User CurrentUser;
        public Messaging DisplayMessage;
        public Security security;
        public string FullName_Master;
        public string TodayDate_Master;
        protected string GalleryPath = "/Attachments/Gallery/";
        protected string ServicesPath = "/Attachments/Services/";


        public void Intialize(User currentUser, string pageNum)
        {
          
            security = new Security(currentUser, pageNum);
            DisplayMessage = new Messaging();
            CurrentUser = currentUser;
            LoadValueOfMaster(currentUser);
        }

        private void LoadValueOfMaster(User currentUser)
        {
            dc = new dbPartoAlaviDataContext();
            
            if (currentUser != null)
                FullName_Master = currentUser.FullName;
            TodayDate_Master = DateShamsi.GetCurrentDate();

        }


        protected void DELETE_FILE(string VirtualUrl, System.Web.HttpServerUtilityBase server)
        {
            try
            {
          
                    string path = server.MapPath(VirtualUrl);
                    if (System.IO.File.Exists(path))
                    {
                        System.IO.File.Delete(path);
                    }
              
                
            }
            catch { }
        }
    }
}