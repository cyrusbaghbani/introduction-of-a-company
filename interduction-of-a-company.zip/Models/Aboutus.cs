﻿using Models;
using PartoEng.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using App_Start.Utility;
using Utility;
using System.ComponentModel.DataAnnotations;

namespace Models
{
    public class M_AboutUs : MasterPageModel
    {

        [Display(Name = "Personal Details:")]
        [Required(ErrorMessage = "Personal Details is required.")]
        [AllowHtml]
        public string txtAboutus { get; set; }
        [AllowHtml]
        public string txtKids { get; set; }
        [AllowHtml]
        public string txtTeen { get; set; }
        [AllowHtml]
        public string txtAdult { get; set; }

        [AllowHtml]
        public string txtChilds { get; set; }


        [AllowHtml]
        public string txtColorSectionAboutUs { get; set; }
        [AllowHtml]
        public string txtColorCategoryCards { get; set; }


        public M_AboutUs()
        {

        }
        public M_AboutUs(User currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            Display();

        }

        public M_AboutUs(FormCollection frm, User currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);

        }
        internal void BindForms(User currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
        
        }
        public void BindForms(FormCollection frm)
        {
            txtAboutus = frm["txtAboutus"].ToString().Trim();
            txtTeen = frm["txtTeen"].ToString().Trim();
            txtKids = frm["txtKids"].ToString().Trim();
            txtAdult = frm["txtAdult"].ToString().Trim();
            txtChilds = frm["txtChilds"].ToString().Trim();
            txtColorCategoryCards = frm["txtColorCategoryCards"].ToString().Trim();
            txtColorSectionAboutUs = frm["txtColorSectionAboutUs"].ToString().Trim();

        }
        public void Save()
        {
            var profile = dc.Profiles.FirstOrDefault();
            if(profile!=null)
            {
                profile.AboutUSInformation = txtAboutus;
                profile.CategoryCardColor = txtColorCategoryCards;
                profile.AboutUsColor = txtColorSectionAboutUs;
            }
            var objKids = dc.Categories.FirstOrDefault(s => s.Id == CategoryType.Kodakan);
            if (objKids != null)
            {
                objKids.Dsc = txtKids;
            }
            var objTeen = dc.Categories.FirstOrDefault(s => s.Id == CategoryType.Nojavanan);
            if (objTeen != null)
            {
                objTeen.Dsc = txtTeen;
            }
            var objAdult = dc.Categories.FirstOrDefault(s => s.Id == CategoryType.Bozorgsalan);
            if (objAdult != null)
            {
                objAdult.Dsc = txtAdult;
            }
            var objchilds = dc.Categories.FirstOrDefault(s => s.Id == CategoryType.Khordsalan);
            if (objchilds != null)
            {
                objchilds.Dsc = txtChilds;
            }
            

            
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
   
            if (Ischange)
            {
                EventLog.Loging(" ویرایش صفحه درباره ما انجام گردید", EventTypeIds.EDIT, CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثبت گردید.");
        }
        private void Display()
        {
            var profile = dc.Profiles.FirstOrDefault();
            var lstcategory = dc.Categories.ToList();
            txtAboutus = profile == null ? "" : profile.AboutUSInformation;
            txtKids = lstcategory.Any(s => s.Id == CategoryType.Kodakan) ? (lstcategory.First(s => s.Id == CategoryType.Kodakan).Dsc) : "";
            txtTeen = lstcategory.Any(s => s.Id == CategoryType.Nojavanan) ? (lstcategory.First(s => s.Id == CategoryType.Nojavanan).Dsc) : "";
            txtAdult = lstcategory.Any(s => s.Id == CategoryType.Bozorgsalan) ? (lstcategory.First(s => s.Id == CategoryType.Bozorgsalan).Dsc) : "";
            txtChilds= lstcategory.Any(s => s.Id == CategoryType.Khordsalan) ? (lstcategory.First(s => s.Id == CategoryType.Khordsalan).Dsc) : "";
            txtColorSectionAboutUs = profile == null ? "" : profile.AboutUsColor;
            txtColorCategoryCards = profile == null ? "" : profile.CategoryCardColor;
        }
    }
}