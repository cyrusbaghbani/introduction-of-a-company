﻿using Models;
using PartoEng.Models;
using System.Web.Mvc;
using System.Collections.Generic;
using System.Linq;
using System;
using App_Start.Utility;
using Utility;

namespace Models
{
    public class M_Profile : MasterPageModel
    {

        public string txtFullName;
        public string txttel;
        public string txtlinkInsta;
        public string txtlinkTelegram;
        public string txtaddress;

        public string txtOldPassword;
        public string txtNewPasswod;
        public string txtReNewPassword;
        public M_Profile(User currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            Display();

        }

        public M_Profile(FormCollection frm, User currentUser_, string PageName)
        {
            Intialize(currentUser_, PageName);
            BindForms(frm);

        }
        public void BindForms(FormCollection frm)
        {
            txtFullName = CurrentUser == null ? "-" : CurrentUser.FullName;
            txttel = frm["txttel"].ToString().Trim();
            txtlinkInsta = frm["txtlinkInsta"].ToString().Trim();
            txtlinkTelegram = frm["txtlinkTelegram"].ToString().Trim();
            txtaddress = frm["txtaddress"].ToString().Trim();

            txtOldPassword = frm["txtOldPassword"].ToString();
            txtNewPasswod = frm["txtNewPasswod"].ToString();
            txtReNewPassword = frm["txtReNewPassword"].ToString();
        }
        public void Save()
        {
            bool IsInsert = false;
            var obj = dc.Profiles.FirstOrDefault();
            if (obj == null)
            {
                IsInsert = true;
                obj = new Profile();
                dc.Profiles.InsertOnSubmit(obj);
            }

            obj.Telephone = txttel;
            obj.Instageram = txtlinkInsta;
            obj.Telegram = txtlinkTelegram;
            obj.Address = txtaddress;
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            if (IsInsert)
            {
                EventLog.Loging(" درج جدید اطلاعات شخصی", EventTypeIds.SAVE, CurrentUser.UID);
            }
            else if (!IsInsert && Ischange)
            {
                EventLog.Loging(" ویرایش اطلاعات شخصی", EventTypeIds.EDIT, CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("اطلاعات با موفقیت ثبت گردید.");
        }
        public void SavePassword()
        {
            var obj = dc.Users.SingleOrDefault(s => s.UID == CurrentUser.UID);
            obj.Password = EncryptedQueryString.GetMD5Hash(txtNewPasswod);
            bool Ischange = dc.GetChangeSet().Updates.Any();
            dc.SubmitChanges();
            CurrentUser = obj;
            if (Ischange)
            {
                EventLog.Loging(" ویرایش رمز عبور", EventTypeIds.EDIT, CurrentUser.UID);
            }
            DisplayMessage.ShowSeccessMessage("رمز عبور با موفقیت تغییر یافت.");
        }
        public bool CheckValidatePassword()
        {
            bool result = true;
            string Msg = "به نکات زیر توجه نمایید" + "</br>";
            int i = 0;
            if (txtOldPassword == "")
            {
                result = false;
                Msg += (++i).ToString() + " - " + " رمز عبور قبلی را وارد نمایید ." + "</br>";
            }
            else if (!dc.Users.Any(s => s.UID == CurrentUser.UID && s.Password == EncryptedQueryString.GetMD5Hash(txtOldPassword)))
            {
                result = false;
                Msg += (++i).ToString() + " - " + " رمز عبور قبلی اشتباه می باشد." + "</br>";
            }
            if (txtNewPasswod == "")
            {
                result = false;
                Msg += (++i).ToString() + " - " + " رمز عبور جدید را وارد نمایید ." + "</br>";
            }
            if (txtReNewPassword == "")
            {
                result = false;
                Msg += (++i).ToString() + " - " + " تکرار رمز عبور حدید را وارد نمایید ." + "</br>";
            }
            if (txtNewPasswod.Length < 6 && txtNewPasswod != "")
            {

                result = false;
                Msg += (++i).ToString() + " - " + " رمز عبور جدید باید بیشتر از 6 حرف داشته باشد ." + "</br>";

            }
            if (txtNewPasswod != ""&& txtReNewPassword!=""&& txtNewPasswod!= txtReNewPassword)
            {
                result = false;
                Msg += (++i).ToString() + " - " + " باید تکرار رمز عبور جدید با رمز عبور جدید برابر باشد." + "</br>";
            }
            if (!result)
                DisplayMessage.ShowErrorMessage(Msg);
            return result;
        }
        private void Display()
        {

            txtOldPassword = "";
            txtNewPasswod = "";
            txtReNewPassword = "";


            var obj = dc.Profiles.FirstOrDefault();
            txtFullName = CurrentUser == null ? "-" : CurrentUser.FullName;
            txttel = obj == null ? "" : obj.Telephone;
            txtlinkInsta = obj == null ? "" : obj.Instageram;
            txtlinkTelegram = obj == null ? "" : obj.Telegram;
            txtaddress = obj == null ? "" : obj.Address;
        }
    }
}