﻿using App_Start.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.IO;
using Utility;
using PartoEng.Models;


namespace Models
{
    public class CMasterController : Controller
    {
        protected dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
        protected User CurrentUser;
        protected string CurrentDate
        {
            get
            {
                return DateShamsi.GetCurrentDate();
            }
        }
        protected Guid? USERID
        {
            get
            {
                try
                {
                    return Session["USERID"] == null ? (Guid?)null : (Guid)Session["USERID"];
                }
                catch { return null; }
            }
        }

        protected string GalleryPath = "/Attachments/Gallery/";
        protected string ServicesPath = "/Attachments/Services/";



        private bool Security()
        {
            try
            {
                CurrentUser = dc.Users.SingleOrDefault(s => s.UID == USERID);
            }
            catch
            {
                CurrentUser = null;
            }
            if (CurrentUser == null)
            {
                Response.Redirect("~/Login/Login");
                return false;
            }
            return true;
        }
        public ActionResult GoToPage(string Action, string Controller, string Parametr = "")
        {
            return RedirectToAction(EmoNetUtility.GetEncodedQueryString(Action, Parametr), Controller);
        }
        public ActionResult GOLOGIN()
        {
            return RedirectToAction("Login", "Login");
        }

        // GET: Security
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (!Security())
            {
                return;
            }

            // Do whatever here...
        }
        public ActionResult EXIT()
        {
            EventLog.Loging(" خروج کاربر از سامانه", EventTypeIds.khorojAzSystem, CurrentUser.UID);
            Session.Remove("USERID");
            return RedirectToAction("Login", "Login");
        }



        #region Delete TEMP FILES

        public void DeleteTempFiles(Guid? UserUID, Guid? ItemUID, int? ItemID, string PageName, string sessenID)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            var q = from p in dc.Temps select p;

            foreach (var p in q)
            {
                try
                {
                    if (DateTime.Now.Subtract(p.DateTime).TotalMinutes > 60)
                    {
                        string path = Server.MapPath(p.Url);
                        if (System.IO.File.Exists(path))
                        {
                            System.IO.File.Delete(path);
                        }
                        dc.Temps.DeleteOnSubmit(p);
                    }
                }
                catch { }

            }
            dc.SubmitChanges();
        }

        #endregion


    }
}