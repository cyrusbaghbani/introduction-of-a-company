﻿using App_Start.Utility;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;
using PartoEng.Models;

namespace Models
{
    public class LoginModel
    {
        dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
        private string txtbox_EMAIL_DIALOG;


        public Messaging DisplayMessage;
        public string txtUserName;
        public string txtPassword;


        public LoginModel()
        {
            DisplayMessage = new Messaging();
        }
        public LoginModel(FormCollection frm, string CaptchaValue_)
        {
            DisplayMessage = new Messaging();
            txtUserName = frm["txtUserName"].ToString().Trim();
            txtPassword = frm["txtPassword"].ToString();

            txtbox_EMAIL_DIALOG = frm["txtbox_EMAIL_DIALOG"].ToString().Trim();


        }

        public string Login()
        {



            var usr = dc.Users.FirstOrDefault(s => s.UserName.ToLower() == txtUserName.ToLower().Trim() && s.Password == Utility.EncryptedQueryString.GetMD5Hash(txtPassword));
            EventLog.Loging("ورود موفق به سیستم", EventTypeIds.VorodBSystem, usr.UID);

            System.Web.HttpContext.Current.Session["USERID"] = usr.UID;


            return "~/AProfile/Profile";

        }



        public bool CheckValidate()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;


            if (txtUserName.Trim() == "")
            {
                Msg += (++i).ToString() + " - " + "نام کاربری را وارد نمایید." + "</br>";
                result = false;
            }
            if (txtPassword == "")
            {
                Msg += (++i).ToString() + " - " + "رمز عبور را وارد نمایید." + "</br>";
                result = false;
            }

            if (result == true)
            {
                var usr = dc.Users.FirstOrDefault(s => s.UserName.ToLower() == txtUserName.ToLower().Trim());
                if (usr == null || usr.Password != Utility.EncryptedQueryString.GetMD5Hash(txtPassword))
                {
                    Msg += (++i).ToString() + " - " + "نام کاربری یا رمز عبور شما نادرست می باشد." + "</br>";
                    result = false;
                }
            }


            if (!result)
            {
                DisplayMessage.ShowErrorMessage(Msg);
                EventLog.Loging(Msg, EventTypeIds.VorodNamovafagh, null);
            }

            return result;
        }
        public void ChangePassword()
        {
            string email = txtbox_EMAIL_DIALOG.Trim();
            string NewPass = (new Random()).Next(1000000, 9999999).ToString();
            User obj = dc.Users.FirstOrDefault(s => s.Email == txtbox_EMAIL_DIALOG.Trim());
            obj.Password = EncryptedQueryString.GetMD5Hash(NewPass);
            dc.SubmitChanges();

            string body = "با سلام" + Environment.NewLine + "رمز عبور جدید برای وارد شدن به سایت موسسه زبان پرتو علوی عبارت است از : " + NewPass;
            Mailer.SendMail(body, "موسسه زبان پرتو علوی", email, false, "رمز عبور جدید");
            DisplayMessage.ShowSeccessMessage("رمز عبور جدید ارسال گردید");
            EventLog.Loging(" رمز عبور به ایمیل ارسال گردید.", EventTypeIds.Forgotpassword, obj.UID);
        }
        public bool CheckValidateEmail()
        {
            bool result = true;
            string Msg = "لطفا به نکات زیر توجه نمایید:" + "</br>";
            int i = 0;

            if (txtbox_EMAIL_DIALOG.Trim() == "")
            {
                Msg += (++i).ToString() + " - " + "پست الکترونیکی  را وارد نمایید." + "</br>";
                result = false;
            }
            else if (!Validation.IsEmail(txtbox_EMAIL_DIALOG.Trim()))
            {
                Msg += (++i).ToString() + " - " + "پست الکترونیکی را صحیح وارد نمایید." + "</br>";
                result = false;
            }

            if (result == true)
            {
                var usr = dc.Users.FirstOrDefault(s => s.Email == txtbox_EMAIL_DIALOG.Trim());
                if (usr == null)
                {
                    Msg += (++i).ToString() + " - " + "کاربری با پست الکترونیکی وارد شده یافت نشد." + "</br>";
                    result = false;
                }
            }


            if (!result)
            {
                DisplayMessage.ShowErrorMessage(Msg);
                EventLog.Loging(Msg, EventTypeIds.Forgotpassword, null);
            }

            return result;
        }
    }
}