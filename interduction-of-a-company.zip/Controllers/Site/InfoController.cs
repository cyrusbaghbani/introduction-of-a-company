﻿using Models;
using PartoEng.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PartoEng.Controllers.Site
{
    public class InfoController : Controller
    {
        // GET: Info
        public ActionResult Details(string id)
        {
            M_SiteInfo obj = new M_SiteInfo(id);
            return View("Details",obj);
        }
        public ActionResult DetailsChild(string id)
        {
            M_SiteInfo obj = new M_SiteInfo(id, SubCategoryType.Calender_Khordsalan.ToString());
            return View("Details", obj);
        }
        [HttpPost]
        public ActionResult GetPortofolio(string Value)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            PortfolioTemplate obj = new PortfolioTemplate();
            var item = dc.Portfolios.Where(s => s.Id.ToString() == Value).FirstOrDefault();
            if(item!=null)
            {
                obj.Title = item.Title;
                obj.videoUrl = item.VideoUrl;
                obj.Imageurl = item.ImageUrl;
                obj.Dsc = item.Dsc.Replace("\n"," <br/> ").Replace("\r","");
            }
            return Json(obj);
        }

    }
}