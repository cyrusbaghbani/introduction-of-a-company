﻿using Models;
using PartoEng.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PartoEng.Controllers.Site
{
    
    public class SMainPageController : Controller
    {
        // GET: SMainPage
        public ActionResult SMainPage()
        {
            M_SIte obj = new M_SIte();
            return View("SMainPage", obj);
        }

        [HttpPost]
        public JsonResult SendMailContact(string txtFullName, string txtTel, string txtMsg)
        {
            dbPartoAlaviDataContext dc = new Models.dbPartoAlaviDataContext();
            var user = dc.Users.First(s => s.UserName == "partoalavi");
            Mailer.SendMail(GetTableValueCantact(txtFullName, txtTel, txtMsg), "فرم ارتباط با ما", (user == null ? "info@parto-alavi.ir" : user.Email), true, "موسسه زبان پرتو علوی");
            return Json("");
        }

   

        public JsonResult SendMailFormHamkar(string txtFirstName, string txtLastName, string txtBirthDate, string txtEducation, string txtTel, string txtAddress, string txtSavabeghKari, string txtTTC)
        {
            dbPartoAlaviDataContext dc = new Models.dbPartoAlaviDataContext();
            var user = dc.Users.First(s => s.UserName == "partoalavi");
            Mailer.SendMail(GetTableValueCoWorker(txtFirstName, txtLastName, txtBirthDate, txtEducation, txtTel, txtAddress, txtSavabeghKari, txtTTC), "فرم درخواست همکاری", (user == null ? "info@parto-alavi.ir" : user.Email), true, "موسسه زبان پرتو علوی");
            return Json("");
        }
        
        public string GetTableValueCoWorker(string txtFirstName,string txtLastName,string txtBirthDate,string txtEducation,string txtTel,string txtAddress,string txtSavabeghKari,string  txtTTC)
        {
            var html = "";
            html += " <table  style=\"width:500px;direction:rtl;float:right;margin:20px;text-align:justify;border:1px solid gray\"> ";
            html += " 	<tr style=\"background-color: #fc5431;\"> ";

            html += " 		<th  colspan=\"2\" style=\"text-align:right;padding:10px\">فرم درخواست همکاری</th> ";
            html += " 	</tr> ";
            html += " 	<tr style=\"border-top:1px solid\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > نام و نام خانوادگی </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtFirstName + " " + txtLastName + " </td> ";
            html += " 	</tr> ";
            html += " 	<tr style=\"border-top:1px solid;background-color: rgba(49, 86, 252, 0.06);\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > تاریخ تولد </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtBirthDate + " </td> ";
            html += " 	</tr > ";
            html += " 	<tr style=\"border-top:1px solid\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > تحصیلات </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtEducation + "  </td> ";
            html += " 	</tr> ";
            html += " 	<tr style=\"border-top:1px solid;background-color: rgba(49, 86, 252, 0.06);\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > شماره تماس </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtTel + " </td> ";
            html += " 	</tr> ";
            html += " 	<tr style=\"border-top:1px solid\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > آدرس </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtAddress + " </td> ";
            html += " 	</tr> ";
            html += " 	<tr style=\"border-top:1px solid;background-color: rgba(49, 86, 252, 0.06);\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > سوابق کاری </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtSavabeghKari + " </td> ";
            html += " 	</tr> ";
            html += " 	<tr style=\"border-top:1px solid\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > دوره های T.T.C </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" > " + txtTTC + " </td>  ";
            html += " 	</tr> ";
            html += " </table> ";


            return html;
        }
        private string GetTableValueCantact(string txtFullName, string txtTel, string txtMsg)
        {
            var html = "";
            html += " <table  style=\"width:500px;direction:rtl;float:right;margin:20px;text-align:justify;border:1px solid gray\"> ";
            html += " 	<tr style=\"background-color: #fc5431;\"> ";

            html += " 		<th  colspan=\"2\" style=\"text-align:right;padding:10px\">فرم درخواست همکاری</th> ";
            html += " 	</tr> ";
            html += " 	<tr style=\"border-top:1px solid\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > نام و نام خانوادگی </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtFullName + " </td> ";
            html += " 	</tr> ";
            html += " 	<tr style=\"border-top:1px solid;background-color: rgba(49, 86, 252, 0.06);\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > شماره تماس </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtTel + " </td> ";
            html += " 	</tr > ";
            html += " 	<tr style=\"border-top:1px solid\"> ";
            html += " 		<td style=\"text-align:left;border-left:1px solid gray;width:150px;padding:10px\" > پیام </td> ";
            html += " 		<td style=\"text-align:right;padding:10px\" >  " + txtMsg + "  </td> ";
            html += " 	</tr> ";

            html += " </table> ";


            return html;
        }
    }
}