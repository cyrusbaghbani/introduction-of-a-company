﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;
using PartoEng.Models;
using System.IO;
using System.Net;

namespace PartoEng.Controllers.Admin
{
    public class AAdultController : CMasterController
    {
        public JsonResult UploadImage(string id)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            string urlpath = "";
            var obj = new Temp();
            obj.UID = Guid.NewGuid();
            dc.Temps.InsertOnSubmit(obj);

            try
            {
                foreach (string file in Request.Files)
                {
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        if (!Validation.ValidationImageFormat(fileContent.ContentType, fileContent.FileName))
                        {
                            return Json("Error");
                        }
                        // get a stream
                        var stream = fileContent.InputStream;
                        // and optionally write the file to disk
                        var fileName = Path.GetFileName(file);
                        urlpath = "/TempFiles/" + fileContent.FileName;
                        var path = Path.Combine(Server.MapPath("~/TempFiles/"), fileContent.FileName);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed");
            }
            obj.Url = urlpath;
            obj.DateTime = DateTime.Now;
            dc.SubmitChanges();
            return Json(Utility.EncryptedQueryString.Encrypt(obj.UID.ToString()) + ";" + urlpath);
        }
        public JsonResult UploadVideo(string id)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            string urlpath = "";
            var obj = new Temp();
            obj.UID = Guid.NewGuid();
            dc.Temps.InsertOnSubmit(obj);

            try
            {
                foreach (string file in Request.Files)
                {
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        //if (!Validation.ValidationVideoFormat(fileContent.ContentType, fileContent.FileName))
                        //{
                        //    return Json("Error");
                        //}
                        // get a stream
                        var stream = fileContent.InputStream;
                        // and optionally write the file to disk
                        var fileName = Path.GetFileName(file);
                        urlpath = "/TempFiles/" + fileContent.FileName;
                        var path = Path.Combine(Server.MapPath("~/TempFiles/"), fileContent.FileName);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed");
            }
            obj.Url = urlpath;
            obj.DateTime = DateTime.Now;
            dc.SubmitChanges();
            return Json(Utility.EncryptedQueryString.Encrypt(obj.UID.ToString()) + ";" + urlpath);
        }

        #region Portfolios 

        public ActionResult Videos()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "AADULT_VIDEOS", CategoryType.Bozorgsalan, SubCategoryType.Video_Adult, "بزرگسالان / ویدیو", "AAdult", "Videos");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Videos(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "AADULT_VIDEOS", CategoryType.Bozorgsalan, SubCategoryType.Video_Adult, "بزرگسالان / ویدیو", "AAdult", "Videos");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("VideoSpec", "AAdult");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("VideoSpec", "AAdult", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }


        public ActionResult Gallery()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "AADULT_GALLERY", CategoryType.Bozorgsalan, SubCategoryType.GalLery_Adult, "بزرگسالان / عکس", "AAdult", "Gallery");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Gallery(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "AADULT_GALLERY", CategoryType.Bozorgsalan, SubCategoryType.GalLery_Adult, "بزرگسالان / عکس", "AAdult", "Gallery");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("GallerySpec", "AAdult");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("GallerySpec", "AAdult", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }

        public ActionResult Book()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "AADULT_BOOK", CategoryType.Bozorgsalan, SubCategoryType.Book_Adult, "بزرگسالان / کتاب", "AAdult", "Book");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Book(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "AADULT_BOOK", CategoryType.Bozorgsalan, SubCategoryType.Book_Adult, "بزرگسالان / کتاب", "AAdult", "Book");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("BookSpec", "AAdult");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("BookSpec", "AAdult", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }

        public ActionResult Calenders()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "AADULT_CALENDER", CategoryType.Bozorgsalan, SubCategoryType.Calender_Adult, "بزرگسالان / تقویم آموزشی", "AAdult", "Calenders");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Calenders(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "AADULT_CALENDER", CategoryType.Bozorgsalan, SubCategoryType.Calender_Adult, "بزرگسالان / تقویم آموزشی", "AAdult", "Calenders");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("CalenderSpec", "AAdult");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("CalenderSpec", "AAdult", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }
        #endregion

        #region PortfolioSpec

        public ActionResult VideoSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "AADULT_VIDEOSPEC", ID, true, SubCategoryType.Video_Adult, "بزرگسالان / ویدیو", "AAdult", "VideoSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioVideoSpec", obj);
        }
        [HttpPost]
        public ActionResult VideoSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "AADULT_VIDEOSPEC", ID, true, SubCategoryType.Video_Adult, "بزرگسالان / ویدیو", "AAdult", "VideoSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage( "Videos", "AAdult");

                }
            }
            return View("PortfolioVideoSpec", obj);
        }

        public ActionResult GallerySpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "AADULT_GALLERYSPEC", ID, false, SubCategoryType.GalLery_Adult, "بزرگسالان / عکس", "AAdult", "GallerySpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult GallerySpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "AADULT_GALLERYSPEC", ID, false, SubCategoryType.GalLery_Adult, "بزرگسالان / عکس", "AAdult", "GallerySpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Gallery", "AAdult");

                }
            }
            return View("PortfolioSpec", obj);
        }
        public ActionResult BookSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "AADULT_BOOKSPEC", ID, false, SubCategoryType.Book_Adult, "بزرگسالان / کتاب", "AAdult", "BookSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult BookSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "AADULT_BOOKSPEC", ID, false, SubCategoryType.Book_Adult, "بزرگسالان / کتاب", "AAdult", "BookSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage( "Book", "AAdult");

                }
            }
            return View("PortfolioSpec", obj);
        }

        public ActionResult CalenderSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "AADULT_CALENDERSPEC", ID, false, SubCategoryType.Calender_Adult, "بزرگسالان / تقویم آموزشی", "AAdult", "CalenderSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult CalenderSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "AADULT_CALENDERSPEC", ID, false, SubCategoryType.Calender_Adult, "بزرگسالان / تقویم آموزشی", "AAdult", "CalenderSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Calenders", "AAdult");

                }
            }
            return View("PortfolioSpec", obj);
        }

        #endregion
    }
}