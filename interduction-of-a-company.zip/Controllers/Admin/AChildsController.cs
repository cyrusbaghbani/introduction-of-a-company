﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;
using PartoEng.Models;
using System.IO;
using System.Net;

namespace PartoEng.Controllers.Admin
{

    public class AChildsController : CMasterController
    {
        public JsonResult UploadImage(string id)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            string urlpath = "";
            var obj = new Temp();
            obj.UID = Guid.NewGuid();
            dc.Temps.InsertOnSubmit(obj);

            try
            {
                foreach (string file in Request.Files)
                {
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        if (!Validation.ValidationImageFormat(fileContent.ContentType, fileContent.FileName))
                        {
                            return Json("Error");
                        }
                        // get a stream
                        var stream = fileContent.InputStream;
                        // and optionally write the file to disk
                        var fileName = Path.GetFileName(file);
                        urlpath = "/TempFiles/" + fileContent.FileName;
                        var path = Path.Combine(Server.MapPath("~/TempFiles/"), fileContent.FileName);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed");
            }
            obj.Url = urlpath;
            obj.DateTime = DateTime.Now;
            dc.SubmitChanges();
            return Json(Utility.EncryptedQueryString.Encrypt(obj.UID.ToString()) + ";" + urlpath);
        }
        public JsonResult UploadVideo(string id)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            string urlpath = "";
            var obj = new Temp();
            obj.UID = Guid.NewGuid();
            dc.Temps.InsertOnSubmit(obj);

            try
            {
                foreach (string file in Request.Files)
                {
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        //if (!Validation.ValidationVideoFormat(fileContent.ContentType, fileContent.FileName))
                        //{
                        //    return Json("Error");
                        //}
                        // get a stream
                        var stream = fileContent.InputStream;
                        // and optionally write the file to disk
                        var fileName = Path.GetFileName(file);
                        urlpath = "/TempFiles/" + fileContent.FileName;
                        var path = Path.Combine(Server.MapPath("~/TempFiles/"), fileContent.FileName);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed");
            }
            obj.Url = urlpath;
            obj.DateTime = DateTime.Now;
            dc.SubmitChanges();
            return Json(Utility.EncryptedQueryString.Encrypt(obj.UID.ToString()) + ";" + urlpath);
        }

        #region Portfolios 
        public ActionResult HandCraft()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ACHILDS_HANDCRAFT", CategoryType.Khordsalan , SubCategoryType.Handcraft_Khordsalan, "خردسالان / کاردستی", "AChilds", "HandCraft");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult HandCraft(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ACHILDS_HANDCRAFT", CategoryType.Khordsalan, SubCategoryType.Handcraft_Khordsalan, "خردسالان / کاردستی", "AChilds", "HandCraft");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("HandCraftSpec", "AChilds");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("HandCraftSpec", "AChilds", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }


        public ActionResult Videos()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ACHILDS_VIDEOS", CategoryType.Khordsalan, SubCategoryType.Video_Khordsalan, "خردسالان / ویدیو", "AChilds", "Videos");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Videos(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ACHILDS_VIDEOS", CategoryType.Khordsalan, SubCategoryType.Video_Khordsalan, "خردسالان / ویدیو", "AChilds", "Videos");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("VideoSpec", "AChilds");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("VideoSpec", "AChilds", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }


        public ActionResult Gallery()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ACHILDS_GALLERY", CategoryType.Khordsalan, SubCategoryType.GalLery_Khordsalan, "خردسالان / عکس", "AChilds", "Gallery");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Gallery(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ACHILDS_GALLERY", CategoryType.Khordsalan, SubCategoryType.GalLery_Khordsalan, "خردسالان / عکس", "AChilds", "Gallery");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("GallerySpec", "AChilds");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("GallerySpec", "AChilds", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }

        public ActionResult Book()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ACHILDS_BOOK", CategoryType.Khordsalan, SubCategoryType.Book_Khordsalan, "خردسالان / کتاب", "AChilds", "Book");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Book(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ACHILDS_BOOK", CategoryType.Khordsalan, SubCategoryType.Book_Khordsalan, "خردسالان / کتاب", "AChilds", "Book");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("BookSpec", "AChilds");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("BookSpec", "AChilds", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }

        public ActionResult Calenders()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ACHILDS_CALENDERS", CategoryType.Khordsalan, SubCategoryType.Calender_Khordsalan, "خردسالان / تقویم آموزشی", "AChilds", "Calenders");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Calenders(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ACHILDS_CALENDERS", CategoryType.Khordsalan, SubCategoryType.Calender_Khordsalan, "خردسالان / تقویم آموزشی", "AChilds", "Calenders");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("CalenderSpec", "AChilds");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("CalenderSpec", "AChilds", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }
        #endregion

        #region PortfolioSpec
        public ActionResult HandCraftSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ACHILDS_HANDCRAFTSPEC", ID, false, SubCategoryType.Handcraft_Khordsalan, "خردسالان / کاردستی", "AChilds", "HandCraftSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult HandCraftSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ACHILDS_HANDCRAFTSPEC", ID, false, SubCategoryType.Handcraft_Khordsalan, "خردسالان / کاردستی", "AChilds", "HandCraftSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("HandCraft", "AChilds");

                }
            }
            return View("PortfolioSpec", obj);
        }
        public ActionResult VideoSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ACHILDS_VIDEOSPEC", ID, true, SubCategoryType.Video_Khordsalan, "خردسالان / ویدیو", "AChilds", "VideoSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioVideoSpec", obj);
        }
        [HttpPost]
        public ActionResult VideoSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ACHILDS_VIDEOSPEC", ID, true, SubCategoryType.Video_Khordsalan, "خردسالان / ویدیو", "AChilds", "VideoSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Videos", "AChilds");

                }
            }
            return View("PortfolioVideoSpec", obj);
        }

        public ActionResult GallerySpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ACHILDS_GALLERYSPEC", ID, false, SubCategoryType.GalLery_Khordsalan, "خردسالان / عکس", "AChilds", "GallerySpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult GallerySpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ACHILDS_GALLERYSPEC", ID, false, SubCategoryType.GalLery_Khordsalan, "خردسالان / عکس", "AChilds", "GallerySpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Gallery", "AChilds");

                }
            }
            return View("PortfolioSpec", obj);
        }
        public ActionResult BookSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ACHILDS_BOOKSPEC", ID, false, SubCategoryType.Book_Khordsalan, "خردسالان / کتاب", "AChilds", "BookSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult BookSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ACHILDS_BOOKSPEC", ID, false, SubCategoryType.Book_Khordsalan, "خردسالان / کتاب", "AChilds", "BookSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Book", "AChilds");

                }
            }
            return View("PortfolioSpec", obj);
        }

        public ActionResult CalenderSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ACHILDS_CALENDERSPEC", ID, false, SubCategoryType.Calender_Khordsalan, "خردسالان / تقویم آموزشی", "AChilds", "CalenderSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult CalenderSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ACHILDS_CALENDERSPEC", ID, false, SubCategoryType.Calender_Khordsalan, "خردسالان / تقویم آموزشی", "AChilds", "CalenderSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Calenders", "AChilds");

                }
            }
            return View("PortfolioSpec", obj);
        }
        #endregion


    }
}