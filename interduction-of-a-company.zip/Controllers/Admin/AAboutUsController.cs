﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PartoEng.Models;
using Models;


namespace PartoEng.Controllers.Admin
{
   
    public class AAboutUsController : CMasterController
    {

        public ActionResult AboutUs()
        {
            M_AboutUs obj = new M_AboutUs(CurrentUser, "AAboutUs_AboutUs");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("AboutUs", obj);
        }

     
        [HttpPost]
        public ActionResult AboutUs(M_AboutUs  obj, string btn)
        {
            obj.BindForms( CurrentUser, "AAboutUs_AboutUs");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "SAVE")
            {
                obj.Save();
            }



            return View("AboutUs", obj);
        }



    }
}