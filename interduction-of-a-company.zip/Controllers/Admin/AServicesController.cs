﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;
using System.Threading.Tasks;
using System.Net;
using System.IO;
using PartoEng.Models;

namespace PartoEng.Controllers.Admin
{
    public class AServicesController : CMasterController
    {

        public ActionResult Services()
        {
            M_ServicesList obj = new M_ServicesList(CurrentUser, "ASERVICES_Services");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Services", obj);
        }
        [HttpPost]
        public ActionResult Services(FormCollection frm, string btn)
        {
            M_ServicesList obj = new M_ServicesList(frm, CurrentUser, "ASERVICES_Services");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("ServiceSpec", "AServices");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("ServiceSpec", "AServices", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Services", obj);
        }

        public ActionResult ServiceSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_ServiceSpec obj = new M_ServiceSpec(CurrentUser, "ASERVICES_Services", ID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("ServiceSpec", obj);
        }
        [HttpPost]
        public ActionResult ServiceSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_ServiceSpec obj = new M_ServiceSpec(frm, CurrentUser, "ASERVICES_Services", ID);
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Services", "AServices");

                }
            }
            return View("ServiceSpec", obj);
        }


        [HttpPost]
        public JsonResult UploadImage(string id)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            string urlpath = "";
            var obj = new Temp();
            obj.UID = Guid.NewGuid();
            dc.Temps.InsertOnSubmit(obj);

            try
            {
                foreach (string file in Request.Files)
                {
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        if (!Validation.ValidationImageFormat(fileContent.ContentType, fileContent.FileName))
                        {
                            return Json("Error");
                        }
                        // get a stream
                        var stream = fileContent.InputStream;
                        // and optionally write the file to disk
                        var fileName = Path.GetFileName(file);
                        urlpath = "/TempFiles/" + fileContent.FileName;
                        var path = Path.Combine(Server.MapPath("~/TempFiles/"), fileContent.FileName);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed");
            }
            obj.Url = urlpath;
            obj.DateTime = DateTime.Now;
            dc.SubmitChanges();
            return Json(Utility.EncryptedQueryString.Encrypt(obj.UID.ToString()) + ";" + urlpath);
        }
    }
}