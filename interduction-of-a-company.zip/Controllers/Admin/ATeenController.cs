﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;
using PartoEng.Models;
using System.IO;
using System.Net;

namespace PartoEng.Controllers.Admin
{
    public class ATeenController : CMasterController
    {

        public JsonResult UploadImage(string id)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            string urlpath = "";
            var obj = new Temp();
            obj.UID = Guid.NewGuid();
            dc.Temps.InsertOnSubmit(obj);

            try
            {
                foreach (string file in Request.Files)
                {
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        if (!Validation.ValidationImageFormat(fileContent.ContentType, fileContent.FileName))
                        {
                            return Json("Error");
                        }
                        // get a stream
                        var stream = fileContent.InputStream;
                        // and optionally write the file to disk
                        var fileName = Path.GetFileName(file);
                        urlpath = "/TempFiles/" + fileContent.FileName;
                        var path = Path.Combine(Server.MapPath("~/TempFiles/"), fileContent.FileName);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed");
            }
            obj.Url = urlpath;
            obj.DateTime = DateTime.Now;
            dc.SubmitChanges();
            return Json(Utility.EncryptedQueryString.Encrypt(obj.UID.ToString()) + ";" + urlpath);
        }
        public JsonResult UploadVideo(string id)
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            string urlpath = "";
            var obj = new Temp();
            obj.UID = Guid.NewGuid();
            dc.Temps.InsertOnSubmit(obj);

            try
            {
                foreach (string file in Request.Files)
                {
                    var fileContent = Request.Files[file];
                    if (fileContent != null && fileContent.ContentLength > 0)
                    {
                        if (!Validation.ValidationVideoFormat(fileContent.ContentType, fileContent.FileName))
                        {
                            return Json("Error");
                        }
                        // get a stream
                        var stream = fileContent.InputStream;
                        // and optionally write the file to disk
                        var fileName = Path.GetFileName(file);
                        urlpath = "/TempFiles/" + fileContent.FileName;
                        var path = Path.Combine(Server.MapPath("~/TempFiles/"), fileContent.FileName);
                        using (var fileStream = System.IO.File.Create(path))
                        {
                            stream.CopyTo(fileStream);
                        }
                    }
                }
            }
            catch (Exception)
            {
                Response.StatusCode = (int)HttpStatusCode.BadRequest;
                return Json("Upload failed");
            }
            obj.Url = urlpath;
            obj.DateTime = DateTime.Now;
            dc.SubmitChanges();
            return Json(Utility.EncryptedQueryString.Encrypt(obj.UID.ToString()) + ";" + urlpath);
        }
        #region Portfolios 

        public ActionResult Videos()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ATEEN_VIDEOS", CategoryType.Nojavanan, SubCategoryType.Video_Teen, "نوجوانان / ویدیو", "ATeen", "Videos");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Videos(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ATEEN_VIDEOS", CategoryType.Nojavanan, SubCategoryType.Video_Teen, "نوجوانان / ویدیو", "ATeen", "Videos");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("VideoSpec", "ATeen");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("VideoSpec", "ATeen", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }


        public ActionResult Gallery()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ATEEN_GALLERY", CategoryType.Nojavanan, SubCategoryType.GalLery_Teen, "نوجوانان / عکس", "ATeen", "Gallery");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Gallery(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ATEEN_GALLERY", CategoryType.Nojavanan, SubCategoryType.GalLery_Teen, "نوجوانان / عکس", "ATeen", "Gallery");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("GallerySpec", "ATeen");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("GallerySpec", "ATeen", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }

        public ActionResult Book()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ATEEN_BOOK", CategoryType.Nojavanan, SubCategoryType.Book_Teen, "نوجوانان / کتاب", "ATeen", "Book");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Book(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ATEEN_BOOK", CategoryType.Nojavanan, SubCategoryType.Book_Teen, "نوجوانان / کتاب", "ATeen", "Book");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("BookSpec", "ATeen");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("BookSpec", "ATeen", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }

        public ActionResult Calenders()
        {
            M_PortfolioList obj = new M_PortfolioList(CurrentUser, "ATEEN_CALENDERS", CategoryType.Nojavanan, SubCategoryType.Calender_Teen, "نوجوانان / تقویم آموزشی", "ATeen", "Calenders");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            obj.LoadList();
            return View("Portfolios", obj);
        }
        [HttpPost]
        public ActionResult Calenders(FormCollection frm, string btn)
        {
            M_PortfolioList obj = new M_PortfolioList(frm, CurrentUser, "ATEEN_CALENDERS", CategoryType.Nojavanan, SubCategoryType.Calender_Teen, "نوجوانان / تقویم آموزشی", "ATeen", "Calenders");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "REMOVE")
            {
                obj.DeleteRow(Server);
            }
            else if (btn == "NEW")
            {
                return GoToPage("CalenderSpec", "ATeen");
            }
            else if (btn == "EDIT")
            {
                return GoToPage("CalenderSpec", "ATeen", "id=" + obj.page_.hf_SelectValueID);
            }

            obj.LoadList();
            return View("Portfolios", obj);
        }
        #endregion

        #region PortfolioSpec

        public ActionResult VideoSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ATEEN_VIDEOSPEC", ID, true, SubCategoryType.Video_Teen, "نوجوانان / ویدیو", "ATeen", "VideoSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioVideoSpec", obj);
        }
        [HttpPost]
        public ActionResult VideoSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ATEEN_VIDEOSPEC", ID, true, SubCategoryType.Video_Teen, "نوجوانان / ویدیو", "ATeen", "VideoSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage( "Videos", "ATeen");

                }
            }
            return View("PortfolioVideoSpec", obj);
        }

        public ActionResult GallerySpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ATEEN_GALLERYSPEC", ID, false, SubCategoryType.GalLery_Teen, "نوجوانان / عکس", "ATeen", "GallerySpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult GallerySpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ATEEN_GALLERYSPEC", ID, false, SubCategoryType.GalLery_Teen, "نوجوانان / عکس", "ATeen", "GallerySpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage( "Gallery", "ATeen");

                }
            }
            return View("PortfolioSpec", obj);
        }
        public ActionResult BookSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ATEEN_BOOKSPEC", ID, false, SubCategoryType.Book_Teen, "نوجوانان / کتاب", "ATeen", "BookSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult BookSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ATEEN_BOOKSPEC", ID, false, SubCategoryType.Book_Teen, "نوجوانان / کتاب", "ATeen", "BookSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage( "Book", "ATeen");

                }
            }
            return View("PortfolioSpec", obj);
        }

        public ActionResult CalenderSpec()
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(CurrentUser, "ATEEN_CALENDERSPEC", ID, false, SubCategoryType.Calender_Teen, "نوجوانان / تقویم آموزشی", "ATeen", "CalenderSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("PortfolioSpec", obj);
        }
        [HttpPost]
        public ActionResult CalenderSpec(FormCollection frm, string btn)
        {
            string ID = (string)RouteData.Values["id"];
            M_PortfolioSpec obj = new M_PortfolioSpec(frm, CurrentUser, "ATEEN_CALENDERSPEC", ID, false, SubCategoryType.Calender_Teen, "نوجوانان / تقویم آموزشی", "ATeen", "CalenderSpec");
            if (!obj.security.IsDisplay)
                return GOLOGIN();
            if (btn == "SAVE")
            {
                if (obj.CheckValidate())
                {
                    obj.Save(Server);
                    return GoToPage("Calenders", "ATeen");

                }
            }
            return View("PortfolioSpec", obj);
        }
        #endregion
    }
}