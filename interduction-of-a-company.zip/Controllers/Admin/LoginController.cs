﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utility;
using Models;
using PartoEng.Models;

namespace restauran.Controllers.Login
{
    public class LoginController : Controller
    {

        // GET: Login
        public ActionResult Login()
        {

            Session.RemoveAll();
            var obj = new LoginModel();
          
            return View("Login", obj);
        }
        [HttpPost]
        public ActionResult Login(FormCollection frm, string btn)
        {
            LoginModel obj = new LoginModel(frm, (string)Session["captchaText"]);
            Session.RemoveAll();
            if (btn == "LOGIN")
            {
                if (obj.CheckValidate())
                {
                    
                    DeleteExpireTemp();
                    Response.Redirect(obj.Login());
                    return null;
                }

            }
            else if (btn == "FORGOTPASSWORD")
            {
                if (obj.CheckValidateEmail())
                    obj.ChangePassword();
            }
     
            return View("Login", obj);
        }
        private void DeleteExpireTemp()
        {
            dbPartoAlaviDataContext dc = new dbPartoAlaviDataContext();
            var q = from p in dc.Temps.ToList()
                    where
                    p.DateTime == null
                    ||
                    DateTime.Now.Subtract(p.DateTime).TotalMinutes > 60
                    select p;

            foreach (var p in q)
            {
                try
                {
                    string path = Server.MapPath(p.Url);
                    if (System.IO.File.Exists(path))
                    {
                        System.IO.File.Delete(path);
                    }
                    dc.Temps.DeleteOnSubmit(p);
                }
                catch { }
            }
            dc.SubmitChanges();
        }


    }
}