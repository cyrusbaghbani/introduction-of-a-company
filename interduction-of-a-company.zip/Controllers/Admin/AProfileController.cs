﻿using PartoEng.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Models;

namespace PartoEng.Controllers.Admin
{

    public class AProfileController : CMasterController
    {

        public ActionResult Profile()
        {
            M_Profile obj = new M_Profile(CurrentUser, "AAboutUs_AboutUs");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            return View("Profile", obj);
        }
        [HttpPost]
        public ActionResult Profile(FormCollection frm, string btn)
        {
            M_Profile obj = new M_Profile(frm, CurrentUser, "AAboutUs_AboutUs");
            if (!obj.security.IsDisplay)
                return GOLOGIN();

            if (btn == "SAVE")
            {
                obj.Save();
            }
            else if (btn == "SAVEPASSWORD")
            {
                if (obj.CheckValidatePassword())
                    obj.SavePassword();
            }



            return View("Profile", obj);
        }

    }
}