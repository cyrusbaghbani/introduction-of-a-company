﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;
using System.IO;

/// <summary>
/// Summary description for TestMail
/// </summary>
public class UploadFilesResult
{
    public string Name { get; set; }
    public int Length { get; set; }
    public string Type { get; set; }

    public string ERRORINFO = "";

    public string SRC = "";

    public string ID = "";
}
public static class Validation
{


    /// <summary>
    /// Checks whether the given Email-Parameter is a valid E-Mail address.
    /// </summary>
    /// <param name="email">Parameter-string that contains an E-Mail address.</param>
    /// <returns>True, when Parameter-string is not null and 
    /// contains a valid E-Mail address;
    /// otherwise false.</returns>
    public static bool IsEmail(string email)
    {
        string MatchEmailPattern =
               @"^(([\w-]+\.)+[\w-]+|([a-zA-Z]{1}|[\w-]{2,}))@"
        + @"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?
				[0-9]{1,2}|25[0-5]|2[0-4][0-9])\."
        + @"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?
				[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
        + @"([a-zA-Z]+[\w-]+\.)+[a-zA-Z]{2,4})$";
        if (email != null) return Regex.IsMatch(email, MatchEmailPattern);
        else return false;
    }

    /// <summary>
    /// نام مرورگر را گرفته و می گوید کاربر از این مرورگر استفاده می کند یا نه
    /// </summary>
    /// <param name="Browsername">نام مرورگر</param>
    /// <returns></returns>
    public static bool IsBrowser(string Browsername)
    {
        string name = HttpContext.Current.Request.Browser.Browser;
        if (name != null && name.ToLower() == Browsername.ToLower())
            return true;
        return false;
    }

    public static string ValidationPDf(string contentType, string fileName, int contentLength, int? MaxLeangh)
    {
        List<string> lstExtentionPdf = new List<string>() { ".pdf" };
        string msg = "";
        int i = 0;
        if (contentLength == 0)
        {
            msg += (++i).ToString() + " - " + "مقدار فایل انتخاب شده برابر صفر است." + "</br>";
        }
        else if (MaxLeangh != null && contentLength > MaxLeangh)
        {
            msg += (++i).ToString() + " - " + "اندازه فایل نباید بیشتر از " + ((int)(MaxLeangh / 1024)).ToString("0") + " کیلوبایت باشد، فایل را صحیح وارد نمایید." + "</br>";
        }
        if (!(contentType.ToLower().Contains("application/pdf")) || !lstExtentionPdf.Contains(Path.GetExtension(fileName.ToLower())))
        {
            msg += (++i).ToString() + " - " + "فرمت فایل را صحیح وارد نمایید." + "</br>";
        }
        return msg;
    }

    public static bool ValidationVideoFormat(string contentType, string fileName)
    {
        List<string> lstExtentionImage = new List<string>() { ".mp4" };


        if (!(contentType.ToLower().Contains("video/mp4")) ||!lstExtentionImage.Contains(Path.GetExtension(fileName.ToLower())))
        {
            return false;
        }

        return true;
    }

    public static bool ValidationImageFormat(string contentType, string fileName)
    {
        List<string> lstExtentionImage = new List<string>() { ".jpg", ".jpeg", ".png", ".gif" };


        if (!(contentType.ToLower().Contains("image/jpeg") || contentType.ToLower().Contains("image/png") || contentType.ToLower().Contains("image/gif")) || !lstExtentionImage.Contains(Path.GetExtension(fileName.ToLower())))
        {
            return false;
        }

        return true;
    }
    public static string ValidationImage(string contentType, string fileName, int? contentLength, int? MaxLeangh, int? Height, int? Width, int? maxHeight, int? maxWidth, int? minHeight, int? minWidth)
    {
        List<string> lstExtentionImage = new List<string>() { ".jpg", ".jpeg", ".png",".gif" };
        string msg = "";
        int i = 0;
        if (contentLength == 0)
        {
            msg += (++i).ToString() + " - " + "مقدار فایل انتخاب شده برابر صفر است." + "</br>";
        }
        else if (MaxLeangh != null && contentLength > MaxLeangh)
        {
            msg += (++i).ToString() + " - " + "اندازه عکس نباید بیشتر از " + ((int)(MaxLeangh / 1024)).ToString("0") + " کیلوبایت باشد، عکس را صحیح وارد نمایید." + "</br>";
        }
        if (!(contentType.ToLower().Contains("image/jpeg") || contentType.ToLower().Contains("image/png") || contentType.ToLower().Contains("image/gif")) || !lstExtentionImage.Contains(Path.GetExtension(fileName.ToLower())))
        {
            msg += (++i).ToString() + " - " + "فرمت عکس را صحیح وارد نمایید." + "</br>";
        }
        if (minHeight != null && Height != null && Height < minHeight)
        {
            msg += (++i).ToString() + " - " + "طول عکس نباید کمتر از " + maxHeight.ToString() + " پیکسل باشد." + "</br>";
        }
        if (minWidth != null && Width != null && Width < minWidth)
        {
            msg += (++i).ToString() + " - " + "عرض عکس نباید کمتر از " + maxWidth.ToString() + " پیکسل باشد." + "</br>";
        }
        if (maxHeight != null && Height != null && Height > maxHeight)
        {
            msg += (++i).ToString() + " - " + "طول عکس نباید بیشتر از " + maxHeight.ToString() + " پیکسل باشد." + "</br>";
        }
        if (maxWidth != null && Width != null && Width > maxWidth)
        {
            msg += (++i).ToString() + " - " + "عرض عکس نباید بیشتر از " + maxWidth.ToString() + " پیکسل باشد." + "</br>";
        }
        return msg;
    }

    /// <summary>
    /// کد ملی را گرفته و می گوید این کد ملی معتبر هست یا خیر
    /// </summary>
    /// <param name="code">کد ملی</param>
    /// <returns></returns>
    public static bool IsNationalCode(string code)
    {
        if (code.Length != 10)
            return false;

        if (code == "0000000000" || code == "1111111111" || code == "2222222222" || code == "3333333333" || code == "4444444444"
            || code == "5555555555" || code == "6666666666" || code == "7777777777" || code == "8888888888" || code == "9999999999"
            )
            return false;

        var tmp = from p in code.ToArray()
                  select new
                  {
                      Num = Convert.ToInt32(p.ToString())
                  };


        var ArrCode = tmp.ToList().Select(p => p.Num).ToArray();


        int ReghamControl = ArrCode[9];

        int b = ArrCode[8] * 2 + ArrCode[7] * 3 + ArrCode[6] * 4 + ArrCode[5] * 5 + ArrCode[4] * 6 + ArrCode[3] * 7 + ArrCode[2] * 8 + ArrCode[1] * 9 + ArrCode[0] * 10;

        int baghimandeh = b % 11;

        if (baghimandeh < 2 && baghimandeh == ReghamControl)
        {
            return true;
        }
        else if (baghimandeh >= 2 && (11 - baghimandeh) == ReghamControl)
            return true;

        return false;
    }
    public static string IsMobileNumber(string mobile)
    {
        mobile = mobile.Trim();
        string str = "";
        string pattern = "[0-9]";
        if (mobile == null)
            return str;
        if (!Regex.IsMatch(mobile, pattern))
            return str;
        if (mobile.Length != 10 && mobile.Length != 11)
            return str;
        string startwith = "9";
        if (mobile.Length == 11)
            startwith = "0" + startwith;
        if (!mobile.StartsWith(startwith))
            return str;
        if (mobile.Length == 10)
            return "0" + mobile;
        return mobile.Trim();
    }
}