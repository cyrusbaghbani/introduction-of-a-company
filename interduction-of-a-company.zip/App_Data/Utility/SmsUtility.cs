﻿
//using SmsIrRestful;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using Utility;

/// <summary>
/// Summary description for SmsUtility
/// </summary>
/// 

//public static class SmsUtility
//{
//    private static string SecurityKey = "EmoNetsoh@27";
//    private static string WebServiceKey = "e2409331becb5887cac29331";
//    private static string MysmsNumber = "30004554554108";

//    /// <summary>
//    /// برای زمانی استفاده می کنم که برای مشتری از قسمت نوبت دهی بخواهیم اس ام اس زمان دار ارسال کنیم
//    /// در صورت کلی می توان پیام های ساده که از قبل تهیه شده است و نیاز به اضاف یا کم کردن اطلاعات نیست از این طریق مستقیم ارسال نماییم 
//    /// </summary>
//    /// <param name="MobileNumber"></param>
//    /// <param name="SmsBody"></param>
//    /// <param name="dt"></param>
//    /// <param name="nobatid"></param>
//    /// <param name="id"></param>
//    private static void SimpleSendSinglesms(string MobileNumber, string SmsBody, DateTime? dt, Guid? nobatid, int id)
//    {
//        try
//        {
//            int cnt = 0;
//            dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
//            var sms = new MessageSm();
//            dc.MessageSms.InsertOnSubmit(sms);
//            sms.UID = Guid.NewGuid();
//            sms.NobatId = nobatid;
//            sms.Message = SmsBody;
//            sms.customerId = id;
//            sms.DateTimeSabt = DateTime.Now;
//            sms.DateErsal = dt == null ? DateShamsi.GetCurrentDate() : DateShamsi.ConvertMiladiDateToPersionDate(dt.Value);
//            sms.TimeErsal = dt == null ? DateShamsi.GetCurrentHour() : (DateShamsi.GetTimeString(dt.Value.Hour.ToString(), dt.Value.Minute.ToString(), dt.Value.Second.ToString(), ":"));
//            sms.IsDeleted = false;



//            try
//            {
//                while (cnt < 5)
//                {
//                    var token = new Token().GetToken(WebServiceKey, SecurityKey);
//                    var messageSendObject = new MessageSendObject()
//                    {
//                        Messages = new List<string> { SmsBody }.ToArray(),
//                        MobileNumbers = new List<string> { MobileNumber }.ToArray(),
//                        LineNumber = MysmsNumber,
//                        SendDateTime = dt,
//                        CanContinueInCaseOfError = true
//                    };


//                    MessageSendResponseObject messageSendResponseObject = new MessageSend().Send(token, messageSendObject);
//                    if (messageSendResponseObject.IsSuccessful)
//                    {
//                        sms.IsMsgSent = true;
//                        try
//                        {
//                            sms.BatchKey = messageSendResponseObject.BatchKey;
//                            sms.ResultMsg = messageSendResponseObject.Message.ToString();
//                            sms.MsgID = messageSendResponseObject.Ids[0].ID.ToString();
//                            break;
//                        }
//                        catch
//                        {
//                            sms.ResultMsg = "خطا در ارسال";
//                            cnt++;
//                        }

//                    }
//                    else
//                    {
//                        sms.IsMsgSent = false;
//                        try
//                        {
//                            sms.BatchKey = messageSendResponseObject.BatchKey;
//                            sms.ResultMsg = messageSendResponseObject.Message.ToString();
//                            sms.MsgID = messageSendResponseObject.Ids[0].ID.ToString();
//                        }
//                        catch
//                        {
//                            sms.ResultMsg = "خطا در ارسال";

//                        }
//                        cnt++;

//                    }
//                }
//                dc.SubmitChanges();
//            }
//            catch
//            {

//            }

//        }
//        catch { }
//    }

//    private static void SendSingleSms(string MobileNumber, string SmsBody, string nobatid, string id)
//    {
//        try
//        {
//            var token = new Token().GetToken(WebServiceKey, SecurityKey);

//            var messageSendObject = new MessageSendObject()
//            {
//                Messages = new List<string> { SmsBody }.ToArray(),
//                MobileNumbers = new List<string> { MobileNumber }.ToArray(),
//                LineNumber = MysmsNumber,
//                SendDateTime = null,
//                CanContinueInCaseOfError = true
//            };

//            try
//            {

//                MessageSendResponseObject messageSendResponseObject = new MessageSend().Send(token, messageSendObject);
//                if (messageSendResponseObject.IsSuccessful)
//                {

//                }
//                else
//                {

//                }
//            }
//            catch
//            {

//            }
//        }
//        catch { }
//    }


//    private static void SendSms(List<string> MobileNumbers, string SmsBody, bool IsUseEmza, bool isUseName, List<string> nobatIds, List<string> Ids)
//    {
//        try
//        {

//            foreach (string id in Ids)
//            {
//                var token = new Token().GetToken(WebServiceKey, SecurityKey);

//                var messageSendObject = new MessageSendObject()
//                {
//                    Messages = new List<string> { SmsBody }.ToArray(),
//                    MobileNumbers = MobileNumbers.ToArray(),
//                    LineNumber = MysmsNumber,
//                    SendDateTime = null,
//                    CanContinueInCaseOfError = true
//                };

//                try
//                {

//                    MessageSendResponseObject messageSendResponseObject = new MessageSend().Send(token, messageSendObject);
//                    if (messageSendResponseObject.IsSuccessful)
//                    {

//                    }
//                    else
//                    {

//                    }
//                }
//                catch
//                {

//                }
//            }
//        }
//        catch
//        {
//        }
//    }


//    private static int? GetDeliveryStatus(long RecID)
//    {
//        // BkhasSms.Send Snd = new BkhasSms.Send();
//        //try
//        //{
//        //    int result = Snd.GetDelivery(RecID);
//        //    return result;

//        //}
//        //catch
//        //{
//        return null;
//        //}
//    }

//    private static string GetStatusImageUrl(int? List_SmsSentStatusID, int? List_SmsDeliveryStatus)
//    {
//        string Url = "";
//        if (List_SmsSentStatusID == null)
//            Url = "";
//        else if (List_SmsSentStatusID != 1)
//            Url = "~/Images/Grid/SmsNotSent.png";
//        else //تا اینجا sms ارسال شده است
//        {
//            if (List_SmsDeliveryStatus == null)
//                Url = "~/Images/Grid/SmsSent.png";
//            else if (List_SmsDeliveryStatus == 1)
//                Url = "~/Images/Grid/SmsDeliverd.png";
//            else if (List_SmsDeliveryStatus == 2)
//                Url = "~/Images/Grid/SmsNotDeliverd.png";
//            else
//                Url = "~/Images/Grid/SmsSent.png";
//        }

//        return Url;
//    }

//    private static string GetStatusString(int? List_SmsSentStatusID, int? List_SmsDeliveryStatus)
//    {
//        string Result = "";
//        if (List_SmsSentStatusID == null)
//            Result = "";
//        else if (List_SmsSentStatusID != 1)
//            Result = "پیامک ارسال نشده است";
//        else //تا اینجا sms ارسال شده است
//        {
//            if (List_SmsDeliveryStatus == null)
//                Result = "پیامک ارسال شده است";
//            else if (List_SmsDeliveryStatus == 1)
//                Result = "پیامک به گوشی رسیده است";
//            else if (List_SmsDeliveryStatus == 2)
//                Result = "پیامک به گوشی نرسیده است";
//            else
//                Result = "پیامک ارسال شده است";
//        }

//        return Result;
//    }

//    public static void SendSingleMessage(string MobileNumber, string SmsBody, string nobatid, string id)
//    {
//        (new Thread(() => SendSingleSms(MobileNumber, SmsBody, nobatid, id))).Start();
//    }
//    public static void SendMessages(List<string> MobileNumbers, string SmsBody, bool IsUseEmza, bool isUseName, List<string> nobatIds, List<string> Ids)
//    {
//        (new Thread(() => SendSms(MobileNumbers, SmsBody, IsUseEmza, isUseName, nobatIds, Ids))).Start();
//    }

//    public static void SimpleSendSingleMessage(string MobileNumber, string SmsBody, DateTime? dt, Guid? nobatid, int id)
//    {
//        (new Thread(() => SimpleSendSinglesms(MobileNumber, SmsBody, dt, nobatid, id))).Start();
//    }
//    public static void SendSms_ToPannel(List<string> idscostomers, string msg, string VaziatEersal)
//    {
//        try
//        {
//            dbAvaSpaDataContext dc = new dbAvaSpaDataContext();
//            foreach (string id in idscostomers)
//            {
//                try
//                {
//                    var obj = dc.Costomers.SingleOrDefault(s => s.Id.ToString() == id);
//                    if (obj != null)
//                    {
//                        string SmsBody = msg;
//                        if (VaziatEersal.ToUpper() == "SIMPLE_SMS")
//                        {
//                            SimpleSendSinglesms(obj.Mobile, SmsBody, null, null, obj.Id);
//                        }
//                        else if (VaziatEersal.ToUpper() == "SIMPLE_NAME")
//                        {
//                            SmsBody = (obj.IsSexWoman == null ? "آقای/خانم " : (obj.IsSexWoman == true ? "خانم " : "آقای "))
//                                + obj.FullName + Environment.NewLine
//                                + SmsBody;
//                            SimpleSendSinglesms(obj.Mobile, SmsBody, null, null, obj.Id);
//                        }
//                        else if (VaziatEersal.ToUpper() == "SIMPLE_SIGN")
//                        {
//                            SmsBody = SmsBody + Environment.NewLine + " با تشکر " + PishfarzSpa.Name + Environment.NewLine + PishfarzSpa.TelNumber;
//                            SimpleSendSinglesms(obj.Mobile, SmsBody, null, null, obj.Id);
//                        }
//                        else if (VaziatEersal.ToUpper() == "SIMPLE_NAME_SIGN")
//                        {
//                            SmsBody = (obj.IsSexWoman == null ? "آقای/خانم " : (obj.IsSexWoman == true ? "خانم " : "آقای "))
//                                + obj.FullName + Environment.NewLine
//                                + SmsBody
//                                + Environment.NewLine + " با تشکر " + PishfarzSpa.Name + Environment.NewLine + PishfarzSpa.TelNumber;
//                            SimpleSendSinglesms(obj.Mobile, SmsBody, null, null, obj.Id);
//                        }
//                    }
//                }
//                catch { }
//            }
//        }
//        catch { }
//    }

//    public static void SendAllSms_ToPannel(List<string> idscostomers, string msg, string VaziatEersal)
//    {
//        new Thread(() => SendSms_ToPannel(idscostomers, msg, VaziatEersal)).Start();
//    }
//}