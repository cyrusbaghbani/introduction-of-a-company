﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;





/// <summary>
/// Summary description for Data_Db
/// </summary>
/// 
public class PortfolioTemplate
{
    public string Title="";
    public string Imageurl="";
    public string Dsc="";
    public string videoUrl="";
}
public static class CategoryType
{

    /// <summary>
    /// 1	کودکان
    /// Emonet
    /// </summary>
    public static int Kodakan = 1;//faghat Sherkat Emonet
    /// <summary>
    /// 2	نوجوانان
    /// Emonet
    /// </summary>
    public static int Nojavanan = 2;//faghat Sherkat Emonet
    /// <summary>
    /// 3	بزرگسالان
    /// </summary>
    public static int Bozorgsalan = 3;
    /// <summary>
    /// 1	خردسالان
    /// Emonet
    /// </summary>
    public static int Khordsalan = 4;//faghat Sherkat Emonet

}

public static class SubCategoryType
{
    public static int Handcraft_Kodakan = 1;  //  1	کاردستی	1
    public static int GalLery_Kodakan = 2;    //  2	عکس	1
    public static int Video_Kodakan = 3;      //  3	ویدیو	1
    public static int Book_Kodakan = 5;      //  5	کتاب	1
    public static int GalLery_Teen = 6; //  6	عکس	2
    public static int Video_Teen = 7;   //  7	ویدیو	2
    public static int Book_Teen = 8;     //  8	کتاب	2
    public static int GalLery_Adult = 9;      //  9	عکس	3
    public static int Video_Adult = 10;        //  10	ویدیو	3
    public static int Book_Adult = 11;          //  11	کتاب	3
    public static int Calender_Kodakan = 12;          //  12	تقویم آموزشی	3
    public static int Calender_Teen = 13;          //  13	تقویم آموزشی	3
    public static int Calender_Adult = 14;          //  14	تقویم آموزشی	3
    public static int Handcraft_Khordsalan = 15;  //  15	کاردستی	4
    public static int GalLery_Khordsalan = 16;    //  16	عکس	4
    public static int Video_Khordsalan = 17;      //  17	ویدیو	4
    public static int Book_Khordsalan = 18;      //  18	کتاب	4
    public static int Calender_Khordsalan = 19;          //  19	تقویم آموزشی	4
    
}
