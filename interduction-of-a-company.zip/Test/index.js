$('.bxslider').bxSlider({
  minSlides: 1,
  maxSlides: 4,
  slideWidth: 468,
  slideMargin: 20,
  auto: true,
});